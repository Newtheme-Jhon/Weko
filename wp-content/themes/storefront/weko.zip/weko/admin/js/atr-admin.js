$ = jQuery.noConflict();

$(document).ready(function(){

    //Aquí nuestro código

})
<?php 

class ATR_Widgets extends WP_Widget{

    public function __construct(){

    }

    public function form( $instance ){

    }

    public function update( $new_instance, $old_instance ){

    }

    public function widget( $args, $instance ){

    }


}

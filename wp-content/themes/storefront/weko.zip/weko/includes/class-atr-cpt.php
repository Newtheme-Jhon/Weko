<?php 
/**
 * Este sera el archivo donde gestionaremos los 
 * Custom Post Type de wordpress
 */

class ATR_CPT{

    public function atr_cpt_weko() {

    }

    public function atr_taxonomia_weko(){

    }

}
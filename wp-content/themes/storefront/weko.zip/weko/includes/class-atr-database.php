<?php 
/**
 * Aqui gestionaremos las consultas a la Base de Datos de WordPress
 */
class ATR_Database{

    protected $usuarios;

    public function __construct(){

        global $wpdb;
        
    }

    public function atr_get_usuarios(){

    }

    public function atr_insert_usuarios(){

    }


    public function atr_update_usuarios(){

    }

    public function atr_delete_usuarios(){

    }

    public function atr_sql_personalizado(){

    }



}
<?php 
/**
 * Esta sera la clase encargada de crear los metaboxes
 */
class ATR_Metaboxes{

    protected $post_type;

    public function __construct(){

        $this->post_type = [''];
        
    }

    public function atr_add_caja_personalizada(){

    }

    public function atr_metacaja_html( $post ){

    }

    public function atr_save_metacaja_datos( $post_id ){

    }

}


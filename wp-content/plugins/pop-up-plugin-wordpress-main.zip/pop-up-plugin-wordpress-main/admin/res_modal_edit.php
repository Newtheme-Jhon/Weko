  <!--Modal-->
<div class="modal modalData" id="modalPreview" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
          <div class="row">
           <div class="col-4 col-sm-4">
                  <div class="class-imgFondo" id="imgFondo" style="background-image: url(/wp-content/uploads/2020/07/beard-1845166_640.jpg)"></div>
           </div>

           <div class="col-8 col-sm-8">
            <div class="row mb-3 mt-2">
               <div class="col-12 col-sm-12 d-flex justify-content-end pd-btnclose">
                      <div class="col-1">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="close">
                           <div class="boton-close">
                             <span aria-hidden="true">x</span>
                           </div>
                        </button>
                      </div>
               </div>
            </div>
              <div class="mb-4 row">
                    <div class="col-12 pd-textmodal">
                            <div class="content-popup text-center">
                                <h4>Título</h4>
                                <h6>subtítulo</h6>
                                 <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. In quaerat odio error cupiditate 
                                  recusandae accusantium rem officia velit architecto, consequuntur deserunt itaque eos! Obcaecati
                                   maiores ipsa delectus, eum quasi labore!
                                 </p>
                            </div>
                    </div>
              </div>
              <div class="mb-5 row">
                <div class="col-12 pd-text-modal btn-callAction text-center">
                    <a href="" class="btn btn-success" target="_blank">
                        <span>título boton</span>
                    </a>
                </div>
              </div>
           </div>
      </div>
      
    </div>
  </div>
</div>